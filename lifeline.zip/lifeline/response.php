<?php
// url= http://localhost/lifeline/response.php?city=Mumbai&&quantity=1
// List of near by hospitals is saved in $hospital_list variable and the number of hospitals in the list can be manipulated by changing values of $count near line 120
 require_once('connect.php');
 //function for obtaining latitude and longitude
 function geocode($address){
 
    // url encode the address
    $address = urlencode($address);
     try{
    // google map geocode api url
    $url = "http://maps.google.com/maps/api/geocode/json?address={$address}";
 
    // get the json response
    $resp_json = file_get_contents($url);
     
    // decode the json
    $resp = json_decode($resp_json, true);
     }catch(Exception $e){
      return;
     }
 
    // response status will be 'OK', if able to geocode given address 
    if($resp['status']=='OK'){
 
        // get the important data
        $lati = $resp['results'][0]['geometry']['location']['lat'];
        $longi = $resp['results'][0]['geometry']['location']['lng'];
        $formatted_address = $resp['results'][0]['formatted_address'];
         
        // verify if data is complete
        if($lati && $longi && $formatted_address){
         
            // put the data in the array
            $data_arr = array();            
             
            array_push(
                $data_arr, 
                    $lati, 
                    $longi, 
                    $formatted_address
                );
             
            return $data_arr;
             
        }else{
            return false;
        }
         
    }else{
        return false;
    }
}

// Class for priority queue
 class PQtest extends SplPriorityQueue
{
    public function compare($priority1, $priority2)
    {
        if ($priority1 === $priority2) return 0;
        return $priority1 < $priority2 ? 1 : -1;
    }
}

$objPQ = new PQtest();
/*For testing:
$objPQ->insert('A',3);
$objPQ->insert('B',6);
$objPQ->insert('C',1);
$objPQ->insert('D',2);

//print_r($objPQ->extract() );

echo "COUNT->".$objPQ->count()."<BR>";

//mode of extraction
$objPQ->setExtractFlags(PQtest::EXTR_BOTH);

//Go to TOP
$objPQ->top();

while($objPQ->valid()){
    print_r($objPQ->current());
    echo "<BR>";
    $objPQ->next();
} 

*/

 if (false)
	{ // If cookie is not set redirect to login page
		header("Location: login.php");
	}
  else{

    $hid = 17; // Extracting value of hospital id from set cookie
    $result = mysqli_query($connection, "SELECT id,hospital,address,latitude,longitude FROM registration where id='$hid' ");
    $user= mysqli_fetch_assoc($result);

  }
  $display =0; // For displaying tables
  
if(isset($_GET['city']) && isset($_GET['quantity'])){

 $count=5;
  $address="Dawle Village, Kausa Mumbra, Opposite Kalsekar Degree College, Near Bharat Gear, Thane, Maharashtra 400612 ";
 	$blood_type=  'A+';
  $city=  htmlentities($_GET['city'] );
  $quantity=  htmlentities($_GET['quantity'] );
  
  if( (!empty($address)&& !empty($blood_type)&& !empty($city)  && !empty($quantity) ) || 1){
    try{
      $loc= geocode($address);
      $latitude=$loc[0];
      $longitude=$loc[1];
      $address_found=1;
    }catch(Exception $e){
      $address_found=0;
    }

    if($address_found){ 



 	    $query = "(SELECT id,hospital,address,latitude,longitude FROM registration where registration.city ='$city' and registration.id in
         (SELECT hospital_database.h_id FROM hospital_database where hd_bloodtype='$blood_type' and hd_bloodunits>=$quantity  ) ORDER BY SQRT( POWER($latitude-registration.latitude,2)+ POWER($longitude-registration.longitude,2) ) LIMIT $count )
         UNION 
         (SELECT id,hospital,address,latitude,longitude FROM registration JOIN hospital_database on hospital_database.h_id=registration.id 
          where registration.city ='$city' and hospital_database.hd_bloodtype='$blood_type' and hospital_database.hd_expiry>CURDATE() and hospital_database.hd_bloodunits>=$quantity ORDER BY hd_expiry LIMIT $count )";
      
 	    $result = mysqli_query($connection, $query);
      
      if($result ){
        $display=1; // For displaying tables
        $hospital_list= array();
  	     while($data= mysqli_fetch_assoc($result)){

            
          array_push( $hospital_list, $data);
         
        }
        header("Content-type:application/json");
        $json=json_encode($hospital_list);
      
        echo $json;


 	    }else{
 		     echo "Search Failed! No Data Found.";
 	    }
    }else{
      echo "Search Failed! Invalid Address, try including city name.";
    }
  }
}
 ?>
